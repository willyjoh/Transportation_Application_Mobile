package com.example.transportation_application;

import java.util.List;

public class Route {

private String locationA;
private String locationB;
private String landMarkA;
private int distance;
private int distance1;
private int distance2;

private int duration;
private int duration1;

private int duration2;

    public int getDistance1() {
        return distance1;
    }

    public void setDistance1(int distance1) {
        this.distance1 = distance1;
    }

    public int getDistance2() {
        return distance2;
    }

    public void setDistance2(int distance2) {
        this.distance2 = distance2;
    }

    public int getDuration1() {
        return duration1;
    }

    public void setDuration1(int duration1) {
        this.duration1 = duration1;
    }

    public int getDuration2() {
        return duration2;
    }

    public void setDuration2(int duration2) {
        this.duration2 = duration2;
    }





    public Route(String locationA, String locationB, String landMarkA, int distance,int distance1, int distance2, int duration, int duration1, int duration2) {
        this.locationA = locationA;
        this.locationB = locationB;
        this.landMarkA = landMarkA;
        this.distance = distance;
        this.duration = duration;
        this.duration1 = duration1;
        this.duration2 = duration2;
        this.distance1 = distance1;
        this.distance2 = distance2;
    }



    public String getLocationA() {
        return locationA;
    }


    public void setLocationA(String locationA) {
        this.locationA = locationA;
    }

    public String getLocationB() {
        return locationB;
    }

    public void setLocationB(String locationB) {
        this.locationB = locationB;
    }

    public String getLandMarkA() {
        return landMarkA;
    }

    public void setLandMarkA(String landMarkA) {
        this.landMarkA = landMarkA;
    }



    public int getDistance() {
        return distance;
    }

    public void setDistance(int distance) {
        this.distance = distance;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }



}
