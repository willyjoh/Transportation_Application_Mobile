package com.example.transportation_application;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;



public class HomeActivity extends AppCompatActivity {

    private TextView locationPointA, locationPointB,locationPointC,locationPointD, locationPointE, landMark2, landMark3, locationPointF,  distance1,distance2, distance3, landMark1, time1, time2, time3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home);

        locationPointA = findViewById(R.id.locationA);
        locationPointB  = findViewById(R.id.locationB);
        locationPointC = findViewById(R.id.locationC);
        locationPointD = findViewById(R.id.locationD);
        locationPointE = findViewById(R.id.locationE);
        locationPointF = findViewById(R.id.locationF);
        landMark2 = findViewById(R.id.landMarkB);
        landMark3 = findViewById(R.id.landMarkC);
        distance1 = findViewById(R.id.routeDistance);
        distance2 = findViewById(R.id.routeDistance1);
        distance3 = findViewById(R.id.routeDistance2);
        landMark1 = findViewById(R.id.landMarkA);
        time1 = findViewById(R.id.routeTime);
        time2 = findViewById(R.id.routeTime1);
        time3 = findViewById(R.id.routeTime2);

        String firstLocationData = getIntent().getStringExtra("locationA");
        String secondLocationData = getIntent().getStringExtra("locationB");
        String thirdLocationData = getIntent().getStringExtra("locationA");
        String fourthLocationData = getIntent().getStringExtra("locationB");
        String fifthLocationData = getIntent().getStringExtra("locationA");
        String sixthLocationData = getIntent().getStringExtra("locationB");
        String landMarkA = getIntent().getStringExtra("landMarkA");
        String landMarkB = getIntent().getStringExtra("landMarkA");
        String landMarkC = getIntent().getStringExtra("landMarkA");
        int firstDistance = getIntent().getIntExtra("routeDistance", 1);
        int secondDistance = getIntent().getIntExtra("route1Distance", 1);
        int thirdDistance = getIntent().getIntExtra("route2Distance", 1);
        int duration1 = getIntent().getIntExtra("routeDuration", 1);
        int duration2 = getIntent().getIntExtra("route1Duration", 1);
        int duration3 = getIntent().getIntExtra("route2Duration", 1);


        locationPointA.setText(firstLocationData+ "-->");
        locationPointB.setText(secondLocationData);
        locationPointC.setText(thirdLocationData+ "-->");
        locationPointD.setText(fourthLocationData);
        locationPointE.setText(fifthLocationData+ "-->");
        locationPointF.setText(sixthLocationData);
        landMark1.setText(""+landMarkA+"--->");
        landMark2.setText(""+landMarkB+"--->");
        landMark3.setText(""+landMarkC+"--->");
        distance1.setText("Distance: "+firstDistance+ "m");
        distance2.setText("Distance: "+secondDistance+ "m");
        distance3.setText("Distance: "+thirdDistance+ "m");
        time1.setText("time: "+duration1+ "min");
        time2.setText("time: "+duration2+ "min");
        time3.setText("time: "+duration3+ "min");






    }
}
