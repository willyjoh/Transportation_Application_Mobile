package com.example.transportation_application;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private Spinner spinnerPointA, spinnerPointB;
    private Button btnSearchRoute;

    private ArrayList<Route> routes = new ArrayList<>();





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Route routeA = new Route("Pent Hostel", "Legon Hall", "Engineering Department", 1900, 2100, 1300,  7, 6, 2);
        Route routeD = new Route("GCB", "Chemistry Department", "Research Commons", 750, 900, 770, 3, 3, 3);
        Route routeI = new Route("Balme Library", "Computer Science Department", "Math Department", 400, 300, 700,  3, 5, 6);


        spinnerPointA = findViewById(R.id.spinner1Location);
        spinnerPointB = findViewById(R.id.spinner2Location);
        btnSearchRoute = findViewById(R.id.displayRoutes);

        routes.add(routeA);
        routes.add(routeD);
        routes.add(routeI);

        ArrayList<String> spinner1Arr = new ArrayList<>();
        for (int i = 0; i < routes.size(); i++) {
            spinner1Arr.add(routes.get(i).getLocationA());
        }

        ArrayList<String> spinner2Arr = new ArrayList<>();
        for (int i = 0; i < routes.size(); i++) {
            spinner2Arr.add(routes.get(i).getLocationB());
        }

        ArrayAdapter adapter1 = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, spinner1Arr);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        ArrayAdapter adapter2 = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, spinner2Arr);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinnerPointA.setAdapter(adapter1);
        spinnerPointB.setAdapter(adapter2);

//        spinnerPointA.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
//            @Override
//            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//             selectedRouteA = (Route) parent.getSelectedItem();
//            }
//
//            @Override
//            public void onNothingSelected(AdapterView<?> parent) {
//            }
//        });
//
//        spinnerPointB.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
//            @Override
//            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//                selectedRouteB = (Route) parent.getSelectedItem();
//
//
//            }
//
//            @Override
//            public void onNothingSelected(AdapterView<?> parent) {
//            }
//        });

        btnSearchRoute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String value1 = spinnerPointA.getSelectedItem().toString();
                String value2 = spinnerPointB.getSelectedItem().toString();

                if(value1.equals("Pent Hostel") && value2.equals("Legon Hall")){
                 Intent intent = new Intent(MainActivity.this, HomeActivity.class);
                 intent.putExtra("locationA", routes.get(0).getLocationA());
                 intent.putExtra("locationB", routes.get(0).getLocationB());
                 intent.putExtra("landMarkA", routes.get(0).getLandMarkA());
                 intent.putExtra("routeDistance", routes.get(0).getDistance());
                 intent.putExtra("route1Distance",routes.get(1).getDistance1());
                 intent.putExtra("route2Distance", routes.get(2).getDistance2());
                 intent.putExtra("routeDuration", routes.get(0).getDuration());
                 intent.putExtra("route1Duration", routes.get(1).getDuration1());
                 intent.putExtra("route2Duration", routes.get(2).getDuration2());
                 Toast.makeText(MainActivity.this, ""+routes.get(0).getDuration1(), Toast.LENGTH_SHORT).show();
                 startActivity(intent);
                } else if (value1.equals("Pent Hostel") && value2.equals("Chemistry Department")) {
                    Intent intent = new Intent(MainActivity.this, HomeActivity.class);
                    intent.putExtra("locationA", routes.get(0).getLocationA());
                    intent.putExtra("locationB", routes.get(1).getLocationB());
                    intent.putExtra("landMarkA", routes.get(2).getLandMarkA());
                    intent.putExtra("routeDistance", routes.get(1).getDistance());
                    intent.putExtra("route1Distance",routes.get(2).getDistance1());
                    intent.putExtra("route2Distance", routes.get(0).getDistance2());
                    intent.putExtra("routeDuration", routes.get(1).getDuration());
                    intent.putExtra("route1Duration", routes.get(0).getDuration1());
                    intent.putExtra("route2Duration", routes.get(1).getDuration2());
                    startActivity(intent);
                } else if (value1.equals("Pent Hostel") && value2.equals("Computer Science Department")) {
                    Intent intent = new Intent(MainActivity.this, HomeActivity.class);
                    intent.putExtra("locationA", routes.get(0).getLocationA());
                    intent.putExtra("locationB", routes.get(2).getLocationB());
                    intent.putExtra("landMarkA", routes.get(1).getLandMarkA());
                    intent.putExtra("routeDistance", routes.get(2).getDistance());
                    intent.putExtra("route1Distance",routes.get(0).getDistance1());
                    intent.putExtra("route2Distance", routes.get(1).getDistance2());
                    intent.putExtra("routeDuration", routes.get(0).getDuration());
                    intent.putExtra("route1Duration", routes.get(2).getDuration1());
                    intent.putExtra("route2Duration", routes.get(0).getDuration2());
                    startActivity(intent);
                }else if (value1.equals("GCB") && value2.equals("Legon Hall")) {
                    Intent intent = new Intent(MainActivity.this, HomeActivity.class);
                    intent.putExtra("locationA", routes.get(1).getLocationA());
                    intent.putExtra("locationB", routes.get(0).getLocationB());
                    intent.putExtra("landMarkA", routes.get(0).getLandMarkA());
                    intent.putExtra("routeDistance", routes.get(0).getDistance());
                    intent.putExtra("route1Distance",routes.get(0).getDistance1());
                    intent.putExtra("route2Distance", routes.get(0).getDistance2());
                    intent.putExtra("routeDuration", routes.get(1).getDuration());
                    intent.putExtra("route1Duration", routes.get(2).getDuration1());
                    intent.putExtra("route2Duration", routes.get(0).getDuration2());
                    startActivity(intent);
                }else if (value1.equals("GCB") && value2.equals("Chemistry Department")) {
                    Intent intent = new Intent(MainActivity.this, HomeActivity.class);
                    intent.putExtra("locationA", routes.get(1).getLocationA());
                    intent.putExtra("locationB", routes.get(1).getLocationB());
                    intent.putExtra("landMarkA", routes.get(1).getLandMarkA());
                    intent.putExtra("routeDistance", routes.get(1).getDistance());
                    intent.putExtra("route1Distance",routes.get(1).getDistance1());
                    intent.putExtra("route2Distance", routes.get(1).getDistance2());
                    intent.putExtra("routeDuration", routes.get(1).getDuration());
                    intent.putExtra("route1Duration", routes.get(1).getDuration1());
                    intent.putExtra("route2Duration", routes.get(1).getDuration2());
                    startActivity(intent);
                }else if (value1.equals("GCB") && value2.equals("Computer Science Department")) {
                    Intent intent = new Intent(MainActivity.this, HomeActivity.class);
                    intent.putExtra("locationA", routes.get(1).getLocationA());
                    intent.putExtra("locationB", routes.get(2).getLocationB());
                    intent.putExtra("landMarkA", routes.get(1).getLandMarkA());
                    intent.putExtra("routeDistance", routes.get(1).getDistance());
                    intent.putExtra("route1Distance",routes.get(0).getDistance1());
                    intent.putExtra("route2Distance", routes.get(2).getDistance2());
                    intent.putExtra("routeDuration", routes.get(2).getDuration());
                    intent.putExtra("route1Duration", routes.get(1).getDuration1());
                    intent.putExtra("route2Duration", routes.get(0).getDuration2());
                    startActivity(intent);
                } else if (value1.equals("Balme Library") && value2.equals("Legon Hall")) {
                    Intent intent = new Intent(MainActivity.this, HomeActivity.class);
                    intent.putExtra("locationA", routes.get(2).getLocationA());
                    intent.putExtra("locationB", routes.get(0).getLocationB());
                    intent.putExtra("landMarkA", routes.get(1).getLandMarkA());
                    intent.putExtra("routeDistance", routes.get(3).getDistance());
                    intent.putExtra("route1Distance",routes.get(0).getDistance1());
                    intent.putExtra("route2Distance", routes.get(0).getDistance2());
                    intent.putExtra("routeDuration", routes.get(0).getDuration());
                    intent.putExtra("route1Duration", routes.get(0).getDuration1());
                    intent.putExtra("route2Duration", routes.get(0).getDuration2());
                    startActivity(intent);
                }else if (value1.equals("Balme Library") && value2.equals("Chemistry Department")) {
                    Intent intent = new Intent(MainActivity.this, HomeActivity.class);
                    intent.putExtra("locationA", routes.get(2).getLocationA());
                    intent.putExtra("locationB", routes.get(1).getLocationB());
                    intent.putExtra("landMarkA", routes.get(0).getLandMarkA());
                    intent.putExtra("routeDistance", routes.get(0).getDistance());
                    intent.putExtra("route1Distance",routes.get(0).getDistance1());
                    intent.putExtra("route2Distance", routes.get(0).getDistance2());
                    intent.putExtra("routeDuration", routes.get(0).getDuration());
                    intent.putExtra("route1Duration", routes.get(0).getDuration1());
                    intent.putExtra("route2Duration", routes.get(0).getDuration2());
                    startActivity(intent);
                }else if (value1.equals("Balme Library") && value2.equals("Computer Science Department")) {
                    Intent intent = new Intent(MainActivity.this, HomeActivity.class);
                    intent.putExtra("locationA", routes.get(2).getLocationA());
                    intent.putExtra("locationB", routes.get(2).getLocationB());
                    intent.putExtra("landMarkA", routes.get(2).getLandMarkA());
                    intent.putExtra("routeDistance", routes.get(2).getDistance());
                    intent.putExtra("route1Distance",routes.get(2).getDistance1());
                    intent.putExtra("route2Distance", routes.get(2).getDistance2());
                    intent.putExtra("routeDuration", routes.get(2).getDuration());
                    intent.putExtra("route1Duration", routes.get(2).getDuration1());
                    intent.putExtra("route2Duration", routes.get(2).getDuration2());
                    startActivity(intent);
                }
            }
        });
    }
}
