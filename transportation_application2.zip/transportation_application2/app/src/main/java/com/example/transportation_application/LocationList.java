package com.example.transportation_application;

import java.util.List;

public class LocationList {
    private String items;

    public String getItems() {
        return items;
    }

    public void setItems(String items) {
        this.items = items;
    }

    public LocationList(String items) {
        this.items = items;
    }



}
